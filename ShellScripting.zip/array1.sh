#!/bin/bash

#In shell scripting, an array is a collection of elements, where each element can be accessed using an index. Arrays in shell scripts are typically 1-dimensional, and indices start at 0.

#Defining Array method 1
echo "Defining Array method1"

Fruit[0]="This"
Fruit[1]="is"
Fruit[2]="My"
Fruit[3]="Fruit"
Fruit[4]="basket"


#Defining Array Method2
echo "Defining Array Method2"
my_cart=("Apple" "Banana" "Cherry")

#Accessing Array Elements- Method 1

echo "Accessing Array Elements- Method1"
echo "First Index: ${my_cart[0]}"
echo "Second Index: ${my_cart[1]}"
echo "Third Index: ${my_cart[2]}"
echo ""
echo ""


#Accessing All Array elements - Method1
echo "Accessing All Array elements - Method1"
echo ${Fruit[@]}
echo ""
echo ""

#Accessing All Array elements - Method2
echo "Accessing All Array elements - Method2"
echo ${Fruit[*]}
echo ""
echo ""

echo "Added 4th Array Orange"
my_cart[3]="Orange"
echo ${my_cart[@]}
echo ""
echo ""

#Accessing Cart elements
echo "Accessing Cart elements"
echo -e "${my_cart[@]}\n"

# Adding elements by specifying the index
echo "Adding elements by specifying the index"
my_cart[3]=kiwi
echo ${my_cart[3]}   # Output: kiwi
echo ""
echo ""

# Adding elements using the += operator
echo "Adding elements using the += operator"
my_cart+=(mango)
echo ${my_cart[4]}   # Output: mango
echo ""
echo ""

#Accessing Cart elements
echo "Accessing Cart elements"
echo ${my_cart[@]}
echo ""
echo ""

# Update an element by assigning a new value to a specific index.
echo "Update an element by assigning a new value to a specific index."
my_cart[1]=blueberry
echo ${my_cart[1]}   # Output: blueberry
echo ""
echo ""

#Accessing Cart elements
echo "Accessing Cart elements"
echo ${my_cart[@]}
echo ""
echo ""

# Remove an element by unsetting it using the unset command
echo "remove an element by unsetting it using the unset command"
unset my_cart[1]
my_cart[1]=pineapple
echo ${my_cart[@]}   # Output: apple cherry kiwi mango
echo ""
echo ""

# get the number of elements in an array
echo "Get the number of elements in an array"
echo ${#my_cart[@]}  # Output: 4
echo ""
echo ""

#Loop through each element using a for loop
echo "Loop through each element using a for loop"
for fruit in "${my_cart[@]}"; do
	echo "Fruit: $fruit"
done
echo ""
echo ""

#loop through the array and match the value to find its index
echo "loop through the array and match the value to find its index"
for i in "${!my_cart[@]}"; do
     if [[ "${my_cart[$i]}" == "mango" ]]; then
	     echo "Index of mango: $i"
     fi
done
echo ""
echo ""

# Sorting an array
echo "Sorting an array"
sorted_array=($(for i in "${my_cart[@]}"; do echo $i; done | sort))
echo ${sorted_array[@]}
echo ""
echo ""

# combining Arrays
echo "Combining Arrays"
array1=(1 2 3)
array2=(4 5 6)
echo ""
echo ""

# Merge arrays
merged_array=("${array1[@]}" "${array2[@]}")
echo ${merged_array[@]}   # Output: 1 2 3 4 5 6
echo ""
echo ""

# Get two elements starting from index 1
echo "Get two elements starting from index 1"
sliced_array=("${my_cart[@]:1:4}")
echo ${sliced_array[@]}   # Output: cherry kiwi
echo ""
echo ""

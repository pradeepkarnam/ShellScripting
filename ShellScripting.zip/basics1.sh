#!/bin/bash

# Author: Basics First

#This is the beginning
pwd
ls
date
echo "Hello World!!!"

# this is end of script

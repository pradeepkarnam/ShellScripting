#!/bin/bash

# In shell scripting, decision-making allows you to control the flow of execution based on conditions.
# Decision-making constructs enable your script to make choices and execute different parts of code 
# depending on whether certain conditions are met. 
# The primary decision-making constructs in Unix shell scripting include 
#if, if-else, if-elif-else, case Let's explore each of these with detailed explanations and examples.

echo "Enter the value of count"
read count

echo ""
echo "---if Statement---"
echo "value of variable count is $count"
echo ""

if [ $count -gt 5 ]; then
    echo "Count is greater than 5."
fi


echo ""
echo ""
echo "---if-else Statement---"


if [ $count -gt 5 ]; then
    echo "Count is greater than 5."
else
    echo "Count is less than or equal to 5."
fi


echo ""
echo ""
echo "---if-elif-else Statement---"


if [ $count -le 18 ]; then
    echo "User is not allowed to drive"
elif [ $count -gt 60 ]; then
    echo "user is not allowed to drive"
else
    echo "Number is allowed to drive"
fi



echo ""
echo ""
echo "---case statement---i"
echo "select fruit apple or banana or orange"
echo ""

read fruit

case $fruit in
    "apple")
        echo "Apple juice order is confirmed!"
        ;;
    "banana")
        echo "Banana milkshake order is confirmed"
        ;;
    "orange")
        echo "Orange juice order is confirmed"
        ;;
    *)
        echo "$fruit juice is out of stock"
        ;;
esac

echo ""
echo ""
echo "Logical operators in if statments"

echo ""
echo ""
echo "AND(&&) statement"

echo "Enter the age of candidate"
read age

echo "Enter the country of candidate"
read country

if [ $age -ge 18 ] && [ "$country" == "INDIA" ]; then
    echo "Eligible to vote in the INDIA."
else
    echo "Not eligible to vote in the INDIA."
fi


echo ""
echo ""
echo "OR(||) statement"

day="Saturday"

if [ "$day" == "Saturday" ] || [ "$day" == "Sunday" ]; then
    echo "It's a weekend!"
else
    echo "It's a weekday."
fi

#The script checks if day is either "Saturday" or "Sunday". If true, it prints "It's a weekend!"

echo ""
echo ""
echo "NOT(!) statement"

file="operators.sh"

if [ ! -e "$file" ]; then
    echo "File does not exist."
else
    echo "File exists."
fi

#The ! operator negates the condition. The script checks if the file "example.txt" does not exist. 
#If it does not exist, it prints "File does not exist."

echo ""
echo ""
echo "Nested If statement"

if [ $count -gt 0 ]; then
    echo "Number is positive."
    if [ $(($count % 2)) -eq 0 ]; then
        echo "Number is even."
    else
        echo "Number is odd."
    fi
else
    echo "Number is not positive."
fi



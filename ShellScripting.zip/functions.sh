#!/bin/bash
#In shell scripting, functions are a powerful feature that allows you to 
#group aset of commands under a single name, which can be invoked anywhere in the script,
#similar to functions in other programming languages.

#This makes scripts more modular, easier to understand, and reusable.

#Syntax:

#Basic Syntax of a Function

# function_name() {
#     commands
#  }

#Or you can define it using the function keyword:

# function function_name {
#    commands
# }


#Example1: A Simple Function
echo -e "Example1: A Simple Function\n"

greet() {
    echo "Hello, $1!"
}

echo "enter name"
name=basicsfirst
greet $name

echo ""

#Example 2: Function with Multiple Arguments

echo -e "Example2:  Function with Multiple Arguments \n"
echo "Enter value of a"
read a
echo "Enter value of b"
read b

add_numbers() {
    sum=$(($1 + $2))
    echo "The sum of $1 and $2 is: $sum"
}

add_numbers $a $b

#Example 3: Returning Values from Functions

echo ""
echo "Example 3: Returning Values from Functions"

multiply_numbers() {
    result=$(($1 * $2))
    echo $result
}

result=$(multiply_numbers $a $b)
variab1=$((a + result))
echo "The result of multiplication is: $variab1"



#Example 4: Functions with Conditional Logic

echo ""
echo "Example 4: Functions with Conditional Logic"

check_even_odd() {
    if [ $(($1 % 2)) -eq 0 ]; then
        echo "$1 is even."
    else
        echo "$1 is odd."
    fi
}

check_even_odd $a
check_even_odd $b


#Example 5: Functions with Loops

echo -e "\nExample 5: Functions with Loops \n"
print_numbers() {
    for i in $(seq 1 $1); do
        echo $i
    done
}

echo -e "printing sequence for $a \n"
print_numbers $a
echo -e "\nprinting sequence for $b"
print_numbers $b



#Example 6: Using Functions for Code Reusability

echo -e "\nExample 6: Using Functions for Code Reusability"

backup_file() {
    if [ -f $1 ]; then
        cp $1 $1.bak
        echo "Backup of $1 created as $1.bak"
    else
        echo "File $1 does not exist."
    fi
}

backup_file loops.sh
backup_file testq.sh 


#Example 7: Local Variables in Functions
#Use Local Variables: To avoid conflicts, use the local keyword to declare variables within functions,
#so they don't affect variables outside the function.


echo -e "\nExample 7: Local Variables in Functions"

calculate_difference() {
    local diff=$(($1 - $2))
    echo "The difference between $1 and $2 is: $diff"
}

calculate_difference $a $b


#!/bin/bash

#Loops in shell scripting are fundamental constructs that allow you to execute a block of code repeatedly based on a specified condition. They help automate repetitive tasks and make scripts more efficient and concise. Here are the main types of loops in shell scripting: while, for, until, and select loops. Let's explore each loop type in detail, along with examples

echo ""
echo "while loop"
echo "The while loop in shell scripting repeatedly executes a block of code as long as a specified condition is true. It checks the condition before executing the loop body."

count=1

while [ $count -le 5 ]; do
    echo "Count is: $count"
    count=$((count + 1))
done

#Explanation:
#The loop initializes count to 1.
#The loop runs as long as the condition [ $count -le 5 ] is true.
#Inside the loop, it prints the current value of count and then increments it by 1.
#The loop stops when count becomes 6.


echo ""
echo ""
echo "for loop"
echo "The for loop in shell scripting iterates over a list of values (such as numbers, words, or filenames) and executes the block of code for each value."

for fruit in apple banana cherry; do
    echo "I like $fruit."
done

#The loop iterates over each item in the list apple banana cherry.
#For each iteration, the variable fruit takes the value of the current item in the list.
#It prints "I like" followed by the fruit name.

echo "Example with a Numeric Range:"
for i in {1..5}; do
    echo "Number: $i"
done

echo ""
echo ""
echo "until loop"

count=1
until [ $count -gt 5 ]; do
    echo "Count is: $count"
    count=$((count + 1))
done

#The loop initializes count to 1.
#The loop runs until the condition [ $count -gt 5 ] becomes true.
#Inside the loop, it prints the current value of count and increments it by 1.
#The loop stops when count becomes 6.


echo -e  "\n"
echo -e "select loop \n"

PS3="Please select a fruit (1-4): "  # Prompt string

select fruit in apple banana cherry "exit"; do
    case $fruit in
        apple)
            echo "You selected apple."
            ;;
        banana)
            echo "You selected banana."
            ;;
        cherry)
            echo "You selected cherry."
            ;;
        "exit")
            echo "Exiting the script."
            break
            ;;
        *)
            echo "Invalid selection. Please try again."
            ;;
    esac
done

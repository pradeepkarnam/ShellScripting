#!/bin/bash

#There are various operators supported by shell.

#Arithmetic Operators
#Relational Operators
#Boolean Operators
#String Operators
#File Test Operators
#Ternary Operator

echo "----Arithmetic Operators----"

a=20
echo "value of a is $a"
b=4
echo "value of b is $b"

val=`expr $a + $b`
echo "a + b : $val"

val2=$((a + b))
echo "val2 Sum: $val2"  # Outputs Sum: 15

val=`expr $a - $b`
echo "a - b : $val"

val2=$((a - b))
echo "val2 difference: $val2"  # Outputs Sum: 15

val=`expr $a \* $b`
echo "a * b : $val"

val2=$((a * b))
echo "val2 multiplication: $val2"  # Outputs Sum: 15

val=`expr $a / $b`
echo "a / b : $val"

val2=$((a / b))
echo "val2 division: $val2"  # Outputs Sum: 15

val=`expr $b % $a`
echo "b % a : $val"

val2=$((b % a))
echo "val2 mod: $val2"  # Outputs Sum: 15

exponent=$((a ** b))
echo "val2 Exponentiation: $exponent"

#Ternary Operator
echo "Ternary Operator"
c=$(( a > b ? 10 : 20 ))  # If a > b, set a to 10, otherwise 20
echo $c  # Outputs 10

if [ $a == $b ]
then
   echo "a is equal to b"
fi

if [ $a != $b ]
then
   echo "a is not equal to b"
fi


echo ""
echo ""
echo ""
echo "----Relational Operators----"

a=10
b=20

if [ $a -eq $b ]
then
   echo "$a -eq $b : a is equal to b"
else
   echo "$a -eq $b: a is not equal to b"
fi

if [ $a -ne $b ]
then
   echo "$a -ne $b: a is not equal to b"
else
   echo "$a -ne $b : a is equal to b"
fi

if [ $a -gt $b ]
then
   echo "$a -gt $b: a is greater than b"
else
   echo "$a -gt $b: a is not greater than b"
fi

if [ $a -lt $b ]
then
   echo "$a -lt $b: a is less than b"
else
   echo "$a -lt $b: a is not less than b"
fi

if [ $a -ge $b ]
then
   echo "$a -ge $b: a is greater or  equal to b"
else
   echo "$a -ge $b: a is not greater or equal to b"
fi

if [ $a -le $b ]
then
   echo "$a -le $b: a is less or  equal to b"
else
   echo "$a -le $b: a is not less or equal to b"
fi


echo ""
echo ""
echo ""
echo "----Boolean Operators-----"
if [ $a != $b ]
then
   echo "$a != $b : a is not equal to b"
else
   echo "$a != $b: a is equal to b"
fi

if [ $a -lt 100 -a $b -gt 15 ]
then
   echo "$a -lt 100 -a $b -gt 15 : returns true"
else
   echo "$a -lt 100 -a $b -gt 15 : returns false"
fi

if [ $a -lt 100 -o $b -gt 100 ]
then
   echo "$a -lt 100 -o $b -gt 100 : returns true"
else
   echo "$a -lt 100 -o $b -gt 100 : returns false"
fi

if [ $a -lt 5 -o $b -gt 100 ]
then
   echo "$a -lt 100 -o $b -gt 100 : returns true"
else
   echo "$a -lt 100 -o $b -gt 100 : returns false"
fi


echo ""
echo ""
echo ""
echo "----String Operators-----"

a="abc"
b="abc"
c=""

if [ $a = $b ]
then
   echo "$a = $b : a is equal to b"
else
   echo "$a = $b: a is not equal to b"
fi

if [ $a != $b ]
then
   echo "$a != $b : a is not equal to b"
else
   echo "$a != $b: a is equal to b"
fi

if [ -z $a ]
then
   echo "-z $a : string length is zero"
else
   echo "-z $a : string length is not zero"
fi

if [ -n $c ]
then
   echo "-n $c : string length is not zero"
else
   echo "-n $c : string length is zero"
fi

if [ $c ]
then
   echo "$c : string is not empty"
else
   echo "$c : string is empty"
fi


echo ""
echo ""
echo ""
echo "----File test Operators-----"

file="/home/basicsfirst/Shellscripting/Sscript/operators.sh"

if [ -r $file ]
then
   echo "File has read access"
else
   echo "File does not have read access"
fi

if [ -w $file ]
then
   echo "File has write permission"
else
   echo "File does not have write permission"
fi

if [ -x $file ]
then
   echo "File has execute permission"
else
   echo "File does not have execute permission"
fi

if [ -f $file ]
then
   echo "File is an ordinary file"
else
   echo "This is sepcial file"
fi

if [ -d $file ]
then
   echo "File is a directory"
else
   echo "This is not a directory"
fi

if [ -s $file ]
then
   echo "File size is not zero"
else
   echo "File size is zero"
fi

if [ -e $file ]
then
   echo "File exists"
else
   echo "File does not exist"
fi

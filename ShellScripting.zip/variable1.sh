#!/bin/bash

echo "What is your name?"
read USER_NAME
echo "Hello, $USER_NAME"

_basics

Valid variableNames
USER_NAME
USSERNAME
Username
UserName
Username_1
Username_2


Invalid variable names
1_Username
-username
user-name
user_name!

Variable_name=Variable_value
Key=value

Var10 "Basics Fist"
Var11 "basics"
Var12 "First"

